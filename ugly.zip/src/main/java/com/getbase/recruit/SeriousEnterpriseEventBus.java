package com.getbase.recruit;

public interface SeriousEnterpriseEventBus {
    public void sendEvent(String event);
}
