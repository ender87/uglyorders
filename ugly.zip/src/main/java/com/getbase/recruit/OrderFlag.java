package com.getbase.recruit;

public enum OrderFlag {
    PRIORITY, DISCOUNTED, INTERNATIONAL, STANDARD;
}
