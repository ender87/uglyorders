package com.getbase.recruit;

import java.math.BigDecimal;

public interface TaxOfficeAdapter {
    public void registerTax(BigDecimal amount);
}
